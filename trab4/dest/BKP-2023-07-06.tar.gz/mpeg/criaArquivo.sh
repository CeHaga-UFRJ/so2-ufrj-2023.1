touch arquivomp3.mp3
touch arquivompeg.mpeg
touch arquivotxt.txt
